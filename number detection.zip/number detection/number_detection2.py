from PIL import Image
import os
import getpass
from tensorflow import keras
import numpy as np

#model directory
model = keras.models.load_model('./detector_model')

user = getpass.getuser()

#images directory (original images)
dir = './png/'

whatsin = os.listdir(dir)

dirs = []
for i in whatsin:
    newdir = dir+i
    dirs.append(newdir)

images = []

for i in dirs:
    image = Image.open(i).convert('L')
    image = image.crop((0, 0, 50, 50))
    images.append(image)


splited_images = []

for i, a in enumerate(images):
    image_checker1 = 0
    image_checker2 = 0
    image1 = a.crop((0, 0, 25, 50))
    image1 = image1.resize((28, 28))
    image_check1 = np.array(image1)
    image_check1 = image_check1.reshape(784).astype('float32')

    for b in image_check1:
        if b != 255.0:
            image_checker1 = 1

    image2 = a.crop((25, 0, 50, 50))
    image2 = image2.resize((28, 28))
    image_check2 = np.array(image2)
    image_check2 = image_check2.reshape(784).astype('float32')

    for b in image_check2:
        if b != 255.0:
            image_checker2 = 1

    image_list = []
    if image_checker1 == 1:
        if image_checker2 == 1:
            image_list = [image1, image2]
        else:
            image_list = [image1]
    else:
        if image_checker2 == 1:
            image_list = [image2]
        else:
            image_list = []

    splited_images.append(image_list)

total_label = []
for i in splited_images:
    one_pic = []
    for image in i:
        image = np.array(image)/255.0
        image = [image]
        image = np.asarray(image)
        image = image.reshape(image.shape[0], 28, 28, 1).astype('float32')
        prediction = model.predict(image)
        prediction = np.argmax(prediction)

        one_pic.append(prediction)

    total_label.append(one_pic)

new_total_label = []
for i in total_label:
    if len(i) == 1:
        new_total_label.append(i[0])
    else:
        number1 = i[0]
        number2 = i[1]
        number = (number1*10)+number2
        new_total_label.append(number)

#list of labels
print(new_total_label)

#how many labels
print(len(new_total_label))