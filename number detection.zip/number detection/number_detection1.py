from tensorflow import keras
import numpy as np
from PIL import Image
import os

dataset_dir = 'C:\\Users\\chh36\\Desktop\\num_dataset\\'
whatsin = os.listdir(dataset_dir)

train_images = []
train_labels = []
for z, i in enumerate(whatsin):
    smaller_dir = dataset_dir+i
    smaller_whatsin = os.listdir(smaller_dir)
    for a in smaller_whatsin:
        image = Image.open(dataset_dir+i+'\\{}'.format(a)).convert('L')
        image = np.array(image)/255.0
        train_images.append(image)

        onehot = []
        for b in range(10):
            onehot.append(0)
        onehot[z] = 1

        train_labels.append(onehot)

train_images = np.asarray(train_images)
train_images = train_images.reshape(train_images.shape[0], 28, 28, 1).astype('float32')

train_labels = np.array(train_labels, dtype='float32')

model = keras.Sequential([
    keras.layers.Flatten(input_shape=(28, 28)),
    keras.layers.Dense(60, activation='relu'),
    keras.layers.Dense(90, activation='relu'),
    keras.layers.Dropout(0.7),
    keras.layers.Dense(120, activation='relu'),
    keras.layers.Dense(10, activation='softmax')
])

model.compile(optimizer='sgd', loss='categorical_crossentropy', metrics=['accuracy'])
model.fit(x=train_images, y=train_labels, epochs=100)

model.save('./detector_model')